from sys import argv

if len(argv) == 2:
    print('The input is:', argv[1])
else:
    print('No input')